# Info-Board
This is a personal project using  react as frontend,express as backend and redux as state management 
