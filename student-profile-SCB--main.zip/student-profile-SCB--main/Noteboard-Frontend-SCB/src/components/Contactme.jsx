import "../styles/contact.css";
const Contactme = () => {
    return ( 
        <div className="contact-Main">
            <section className="indi-card">1</section>
            <section className="indi-card">2</section>
            <section className="indi-card">3</section>
            <section className="indi-card">4</section>
        </div>
     );
}
 
export default Contactme;